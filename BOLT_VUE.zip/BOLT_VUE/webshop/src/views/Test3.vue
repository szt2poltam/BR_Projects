<script setup>
import MenubarTest3 from '../components/MenubarTest3.vue';
import Cart from '../components/Cart.vue';
</script>

<template>
    <div class="container">
        <MenubarTest3/>
        <Cart/>
    </div>
</template>



<style scoped>
.container{
        max-width: 100vw;
        height: 100vh;
        display: flex;
        align-items: center;
        flex-direction: column;
    }
</style>