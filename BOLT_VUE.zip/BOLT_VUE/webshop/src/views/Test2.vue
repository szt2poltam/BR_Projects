<script setup>
import MenubarTest2 from '../components/MenubarTest2.vue';
import NewItem from '../components/NewItem.vue';
</script>

<template>
    <div class="container">
        <MenubarTest2/>
        <NewItem/>
    </div>
</template>



<style scoped>
.container{
        max-width: 100vw;
        height: 100vh;
        display: flex;
        align-items: center;
        flex-direction: column;
    }
</style>