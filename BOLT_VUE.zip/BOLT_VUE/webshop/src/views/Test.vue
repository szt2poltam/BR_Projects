<script setup>
import Menubar from '@/components/Menubar.vue';
import ItemList from '@/components/ItemList.vue';
</script>

<template>
    <div class="container">
        <Menubar/>
        <ItemList/>
    </div>
</template>

<style scoped>
    .container{
        max-width: 100vw;
        height: 100vh;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
</style>