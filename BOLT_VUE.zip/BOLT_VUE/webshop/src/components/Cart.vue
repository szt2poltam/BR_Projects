<script setup>
import axios from 'axios';
import { ref, onMounted } from 'vue';

const products = ref([]);

const fetchData = async () => {
  try {
    const response = await axios.get('http://localhost:3000/cart');
    products.value = response.data;
  } catch (error) {
    console.error('Hiba történt a lekérdezés során:', error);
  }
};

onMounted(() => {
  fetchData();
});
</script>

<template>
  <div class="main-container">
    <div id="card" class="product-card" v-for="product in products" :key="product.id">
      <div class="img-container">
        <img src="../../../no-image.png" alt="">
      </div>
      <div class="name-container">
        <h3 class="name">{{ product.name }}</h3>
      </div>
      <div class="price-container">
        <p class="price">{{ product.price }} Ft</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.main-container {
  margin-top: 120px;
  background-color: #fff;
  padding: 15px;
  width: 75%;
  height: 100vh;
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}

/* Stílusok a termékekhez */
.product-card {
  min-height: 300px;
  width: 200px;
  margin: 10px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  border: 1px solid black;
  border-radius: 20px;
  background-color: #fff;
  box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;
}

.img-container{
  border-bottom: 1px solid black;
  background-color: green;
  margin-bottom: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 40%;
}

img{
  width: 100%;
  height: 100%;
}

.name-container{
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  width: 100%;
  height: 30%;
}

.name{
  font-size: 18px;
  letter-spacing: -.5px;
  text-transform: capitalize;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}

.price-container{
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  width: 100%;
  height: 20%;
}

.price{
  letter-spacing: -.9px;
  font-size: 30px;
  font-weight: bold;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}

</style>