<script setup>

</script>


<template>
    <div class="main-container">
            <h1 class="logo">Új termék</h1>
            <router-link to="test" id="new-item" class="link">Bolt</router-link>
            <router-link to="test3" id="cart" class="link">Kosár</router-link>
    </div>
</template>


<style scoped>

    .main-container{
        background-color: rgb(175, 179, 177);
        border-bottom-left-radius: 20px;
        border-bottom-right-radius: 20px;
        width: 80%;
        height: 8vh;
        display: flex;
        position: absolute;
    }

    #new-item{
        position: relative;
        top: 15px;
        left: 10%;
    }

    #cart{
        position: relative;
        top: 15px;
        left: 12%;
    }
</style>