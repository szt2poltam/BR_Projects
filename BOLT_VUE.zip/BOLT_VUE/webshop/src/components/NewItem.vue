<script setup>
import { reactive } from 'vue';
import axios from 'axios';

const state = reactive({
  itemName: '',
  itemPrice: ''
});

const addItem = () => {
  axios.post("http://localhost:3000/products", {
    name: state.itemName,
    price: state.itemPrice,
    img: "no-image.png"
  });

  // További műveletek, például adatok frissítése vagy visszajelzés megjelenítése
}
</script>

<template>
    <div class="main-container">
        <div class="new-item-form">
            <input type="text" placeholder="Név" v-model="state.itemName">
            <input type="text" placeholder="Ár" v-model="state.itemPrice">
            <div class="button-container">
                <button class="btn" @click = "addItem">Hozzáadás</button>
            </div>
        </div>
    </div>
</template>

<style scoped>
.main-container{
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.new-item-form{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: absolute;
    width: 80%;
    height: 70%;
}

.form-container{
    display: flex;
    flex-direction: column;
    gap: 40px;
    transform: translate(-50px, -50px);
    height: 85px;
}

.button-container{
    height: 50px;
    width: 131.7px;
}

.btn {
  align-items: center;
  background-color: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.1);
  border-radius: .25rem;
  box-shadow: rgba(0, 0, 0, 0.02) 0 1px 3px 0;
  box-sizing: border-box;
  color: rgba(0, 0, 0, 0.85);
  cursor: pointer;
  display: inline-flex;
  font-family: system-ui,-apple-system,system-ui,"Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size: 16px;
  font-weight: 600;
  justify-content: center;
  line-height: 1.25;
  margin: 0;
  height: 50px;
  padding: calc(.875rem - 1px) calc(1.5rem - 1px);
  position: relative;
  text-decoration: none;
  transition: all 250ms;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: baseline;
  width: auto;
}

.btn:hover,
.btn:focus {
  border-color: rgba(0, 0, 0, 0.15);
  box-shadow: rgba(0, 0, 0, 0.1) 0 4px 12px;
  color: rgba(0, 0, 0, 0.65);
}

.btn:hover {
  transform: translateY(-1px);
}

.btn:active {
  background-color: #F0F0F1;
  border-color: rgba(0, 0, 0, 0.15);
  box-shadow: rgba(0, 0, 0, 0.06) 0 2px 4px;
  color: rgba(0, 0, 0, 0.65);
  transform: translateY(0);
}

</style>